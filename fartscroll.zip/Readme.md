# Getting Started

Open the index.html file in chrome. The library won't play fart sounds unless the user interacts with the page first.